# hsrminer-neo
added proper .dll files
